<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meus cometários</title>
</head>
<body>
  

<?php
    $previsaoDeTempo ="Chuvoso";

    echo "Como o tempo está ".$previsaoDeTempo  ;
    //* echo "Meu casa é".$COR."<br>";
    /* 
    echo "Meu barco é".$coR."<br>";
    echo "Meu avião é".$coR."<br>"; */
  ?>
</body>
</html>