<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Variáveis</title>
</head>
<body>
  
<?php
    $x = 5;
    $y = "Kauê";

    echo "O valor da variável é ".$x.", ".$y;

  ?>
</body>
</html>