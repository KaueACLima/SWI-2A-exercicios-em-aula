<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Couta Palavra</title>
</head>
<body>
  
<?php

echo str_word_count("Olá mundo!");

  ?>
</body>
</html>